export class Settings {
	ApiEndPoint: string = "https://api.cosmicjs.com/v1/numerouno/";
	ApiReadKey: string = "XpAQC8ytDL2Ae6xJLAfBXu7UOF5kIs1ontNdD07Upng1Mc4pwg";
	ApiWriteKey: string = "LKhJLh7cEeoDpGJxwAWRaahbSOOXglnet0vcr61qsdCL4FvM24";
}

export const SpotTypes = ['Vacant', 'Rent', 'Owned'];
