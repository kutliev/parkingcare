import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eventcard',
  templateUrl: './eventcard.component.html',
  styleUrls: ['./eventcard.component.css']
})
export class EventcardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
